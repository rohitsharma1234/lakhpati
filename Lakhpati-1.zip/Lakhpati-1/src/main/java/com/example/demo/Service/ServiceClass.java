package com.example.demo.Service;

import java.util.List;

//import org.hibernate.dialect.MySQL8Dialect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.demo.example.Entity.EntityClass;
import com.example.demo.User.UserClass;


@EnableAutoConfiguration
@Service
public class ServiceClass implements ServiceClassImpl{

	//MySQL8Dialect
	
	@Autowired 
	private UserClass userClass;
	
	@Override
	public List<EntityClass> getCompleted() {
		return userClass.findAll();
		//return "hello world";
		
	}
	
}
