package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

//import javax.xml.transform.Result;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.example.Entity.EntityClass;
import com.example.demo.Service.ServiceClass;

@RestController
public class ControllerClass {
	
	@Autowired
	private ServiceClass serviceClass;
	

	@GetMapping("/getCompleted")
	public List<EntityClass> getCompleted(){
		//String query="select * from Contests where id=1";
		//System.out.println(query);
		 return serviceClass.getCompleted();
		 
	}
}
