package com.example.demo.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.demo.example.Entity.EntityClass;

@Repository
public interface UserClass extends JpaRepository<EntityClass,Integer>{

	//@Query("select * from Contests")
	//public String getCompleted();
	
}
