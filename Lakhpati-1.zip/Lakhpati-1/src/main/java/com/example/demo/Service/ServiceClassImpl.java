package com.example.demo.Service;

import java.util.List;

import com.demo.example.Entity.EntityClass;

public interface ServiceClassImpl {

	List<EntityClass> getCompleted();

	
}
